/* Odoo-style column headers for admin tables.
 *
 *  - Click a header  -> sort A-Z, click again Z-A, third click clears the sort.
 *    Done in the browser on the same page: on the model lists Django's own
 *    sort links (which load a new page) are switched off.
 *  - Funnel icon     -> Excel/Odoo-like popup with a search box and a list of
 *    the values in that column; untick values to hide those rows.
 *  - Report tables can choose per column with <th data-filter="...">:
 *      none  -> sorting only, no funnel icon
 *      list  -> the value list above (default, also used by model lists)
 *      range -> four fixed buckets: 0-9, 10-19, 20-29, 30+
 *
 * Works on `table.report-table` (Reports) and `#result_list` (model lists).
 * Sorting and filtering happen in the browser, so on a paginated model list
 * they only cover the rows on the current page.
 * Language comes from window.BSHOP_LANG (set in admin/base_site.html).
 */
(function () {
  'use strict';

  var EN = (window.BSHOP_LANG || document.documentElement.lang || 'mn').indexOf('en') === 0;
  var L = EN
    ? { search: 'Search…', all: 'All', clear: 'Clear filter', empty: '(empty)', none: 'No matches' }
    : { search: 'Хайх…', all: 'Бүгд', clear: 'Цэвэрлэх', empty: '(хоосон)', none: 'Олдсонгүй' };

  // Fixed buckets for filter-mode "range". bucketOf() gives the index of the
  // bucket a number falls in; blank / non-numeric cells fall in none of them.
  var BUCKETS = ['0 – 500000', '500001 – 1000000', '1000001 – 1500000', EN ? '1500001 and up' : '1500001-с дээш'];
  function bucketOf(text) {
    if (isBlank(text)) return -1;
    var n = parseFloat(text.replace(/[,\s]/g, ''));
    if (isNaN(n)) return -1;
    return n < 500001 ? 0 : n < 1000001 ? 1 : n < 1500001 ? 2 : 3;
  }

  var FUNNEL = '<svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">' +
    '<path d="M1.5 1.5A.5.5 0 0 1 2 1h12a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.128.334L10 8.692V13.5a.5.5 0 0 1-.342.474l-3 1A.5.5 0 0 1 6 14.5V8.692L1.628 3.834A.5.5 0 0 1 1.5 3.5v-2z"/></svg>';

  var css = document.createElement('style');
  css.textContent =
    '.tf-tools{display:inline-flex;align-items:center;gap:4px;margin-left:6px;vertical-align:middle}' +
    '.tf-arrow{font-size:9px;opacity:.85;min-width:8px}' +
    '.tf-btn{border:0;background:transparent;color:inherit;opacity:.45;cursor:pointer;padding:2px 3px;border-radius:4px;line-height:0}' +
    '.tf-btn:hover{opacity:1;background:rgba(128,128,128,.18)}' +
    '.tf-btn.active{opacity:1;color:var(--primary,#417690)}' +
    'table.tf-sortable thead th.tf-sortable-th{cursor:pointer;user-select:none}' +
    'table.tf-sortable .sortoptions{display:none}' +
    'table.tf-sortable thead th.tf-sortable-th a{cursor:pointer}' +
    '.tf-pop{position:absolute;z-index:99998;width:230px;padding:8px;background:var(--body-bg,#fff);color:var(--body-fg,#333);' +
    'border:1px solid var(--hairline-color,#ddd);border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.2);font-size:13px;' +
    'text-transform:none;letter-spacing:0;font-weight:400;opacity:0;transform:translateY(-6px);transition:opacity .5s ease,transform .5s ease}' +
    '.tf-pop.show{opacity:1;transform:none}' +
    '.tf-pop input[type=search]{width:100%;box-sizing:border-box;padding:6px 8px;margin-bottom:6px}' +
    '.tf-list{max-height:220px;overflow:auto;border-top:1px solid var(--hairline-color,#ddd);padding-top:4px}' +
    '.tf-list label{display:flex;align-items:center;gap:6px;padding:3px 2px;cursor:pointer;word-break:break-word}' +
    '.tf-list label:hover{background:var(--darkened-bg,#f5f5f5)}' +
    '.tf-list input{margin:0;flex:none}' +
    '.tf-foot{display:flex;justify-content:space-between;margin-top:6px}' +
    '.tf-foot button{border:0;background:transparent;color:var(--link-fg,#447e9b);cursor:pointer;font-size:12px;padding:2px}' +
    '.tf-none{padding:6px 2px;color:var(--body-quiet-color,#888)}';
  document.head.appendChild(css);

  var openPop = null;
  function closePop() {
    if (!openPop) return;
    var gone = openPop;
    openPop = null;
    gone.classList.remove('show');                       // fade out 0.5 s, then remove
    setTimeout(function () { gone.remove(); }, 500);
  }
  document.addEventListener('click', function (e) {
    if (openPop && !openPop.contains(e.target) && !e.target.closest('.tf-btn')) closePop();
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePop(); });

  function cellText(row, i) {
    var c = row.cells[i];
    return c ? c.textContent.replace(/\s+/g, ' ').trim() : '';
  }
  function isBlank(v) { return v === '' || v === '—' || v === '-'; }

  function init(table) {
    var thead = table.tHead, tbody = table.tBodies[0];
    if (!thead || !tbody) return;
    var headers = Array.prototype.slice.call(thead.rows[0].cells);
    var rows = Array.prototype.slice.call(tbody.rows).filter(function (r) {
      return !r.querySelector('td[colspan]');
    });
    if (!rows.length) return;
    rows.forEach(function (r, i) { r._tfIndex = i; });

    var filters = {};                                  // col -> Set of allowed values, or {range: Set of bucket indexes}
    var sort = { col: -1, dir: 0 };

    function apply() {
      rows.forEach(function (r) {
        var show = true;
        for (var c in filters) {
          var f = filters[c];
          var ok = f.range ? f.range.has(bucketOf(cellText(r, +c))) : f.has(cellText(r, +c));
          if (!ok) { show = false; break; }
        }
        r.style.display = show ? '' : 'none';
      });
    }

    function doSort() {
      var col = sort.col, dir = sort.dir;
      var list = rows.slice();
      if (dir === 0 || col < 0) {
        list.sort(function (a, b) { return a._tfIndex - b._tfIndex; });
      } else {
        var vals = list.map(function (r) { return cellText(r, col); });
        var numeric = vals.every(function (v) { return isBlank(v) || /^-?[\d.,\s]+$/.test(v); });
        var key = function (r) {
          var v = cellText(r, col);
          if (isBlank(v)) return null;
          return numeric ? parseFloat(v.replace(/[,\s]/g, '')) : v;
        };
        list.sort(function (a, b) {
          var x = key(a), y = key(b);
          if (x === null && y === null) return 0;
          if (x === null) return 1;                    // empty cells always last
          if (y === null) return -1;
          var r = numeric ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true, sensitivity: 'base' });
          return dir * r;
        });
      }
      list.forEach(function (r) { tbody.appendChild(r); });
      updateArrows();
    }

    function updateArrows() {
      headers.forEach(function (h, i) {
        var a = h.querySelector('.tf-arrow');
        if (a) a.textContent = (i === sort.col && sort.dir) ? (sort.dir === 1 ? '▲' : '▼') : '';
        if (i === sort.col) return;
        h.classList.remove('sorted', 'ascending', 'descending');
      });
    }

    function placePopup(pop, btn) {
      document.body.appendChild(pop);
      var r = btn.getBoundingClientRect();
      var left = r.left + window.scrollX;
      left = Math.min(left, window.scrollX + document.documentElement.clientWidth - 240);
      pop.style.left = Math.max(4, left) + 'px';
      pop.style.top = (r.bottom + window.scrollY + 4) + 'px';
      openPop = pop;
      requestAnimationFrame(function () { requestAnimationFrame(function () { pop.classList.add('show'); }); });
    }

    // Filter-mode "range": a tick-list of the four fixed buckets.
    function buildRangePopup(col, btn) {
      closePop();
      var allowed = filters[col] ? new Set(filters[col].range) : new Set([0, 1, 2, 3]);
      var pop = document.createElement('div');
      pop.className = 'tf-pop';
      var list = document.createElement('div');
      list.className = 'tf-list';
      list.style.borderTop = '0';
      var foot = document.createElement('div');
      foot.className = 'tf-foot';
      var clear = document.createElement('button');
      clear.type = 'button'; clear.textContent = L.clear;
      foot.appendChild(clear);
      pop.append(list, foot);

      function commit() {
        if (allowed.size === BUCKETS.length) delete filters[col]; else filters[col] = { range: new Set(allowed) };
        btn.classList.toggle('active', !!filters[col]);
        apply();
      }
      function renderList() {
        list.innerHTML = '';
        BUCKETS.forEach(function (label, i) {
          var lbl = document.createElement('label');
          var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = allowed.has(i);
          cb.onchange = function () { if (cb.checked) allowed.add(i); else allowed.delete(i); commit(); };
          lbl.append(cb, document.createTextNode(label));
          list.appendChild(lbl);
        });
      }
      clear.onclick = function () { allowed = new Set([0, 1, 2, 3]); commit(); renderList(); };
      renderList();
      placePopup(pop, btn);
    }

    function buildPopup(col, btn) {
      if (btn._mode === 'range') return buildRangePopup(col, btn);
      closePop();
      var values = [];
      var seen = {};
      rows.forEach(function (r) {
        var v = cellText(r, col);
        if (!seen.hasOwnProperty(v)) { seen[v] = 1; values.push(v); }
      });
      var numeric = values.every(function (v) { return isBlank(v) || /^-?[\d.,\s]+$/.test(v); });
      values.sort(function (a, b) {
        if (numeric) return (parseFloat(a.replace(/[,\s]/g, '')) || 0) - (parseFloat(b.replace(/[,\s]/g, '')) || 0);
        return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
      });
      var allowed = filters[col] ? new Set(filters[col]) : new Set(values);

      var pop = document.createElement('div');
      pop.className = 'tf-pop';
      var search = document.createElement('input');
      search.type = 'search'; search.placeholder = L.search;
      var list = document.createElement('div');
      list.className = 'tf-list';
      var foot = document.createElement('div');
      foot.className = 'tf-foot';
      var clear = document.createElement('button');
      clear.type = 'button'; clear.textContent = L.clear;
      foot.appendChild(clear);
      pop.append(search, list, foot);

      function commit() {
        if (allowed.size === values.length) delete filters[col]; else filters[col] = new Set(allowed);
        btn.classList.toggle('active', !!filters[col]);
        apply();
      }

      function renderList() {
        var q = search.value.trim().toLowerCase();
        var shown = values.filter(function (v) { return (isBlank(v) ? L.empty : v).toLowerCase().indexOf(q) !== -1; });
        list.innerHTML = '';
        if (!shown.length) { var n = document.createElement('div'); n.className = 'tf-none'; n.textContent = L.none; list.appendChild(n); return; }

        var allLbl = document.createElement('label');
        var allCb = document.createElement('input'); allCb.type = 'checkbox';
        allCb.checked = shown.every(function (v) { return allowed.has(v); });
        allLbl.append(allCb, document.createTextNode(L.all));
        allCb.onchange = function () {
          shown.forEach(function (v) { if (allCb.checked) allowed.add(v); else allowed.delete(v); });
          commit(); renderList();
        };
        list.appendChild(allLbl);

        shown.forEach(function (v) {
          var lbl = document.createElement('label');
          var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = allowed.has(v);
          cb.onchange = function () {
            if (cb.checked) allowed.add(v); else allowed.delete(v);
            commit();
            allCb.checked = shown.every(function (x) { return allowed.has(x); });
          };
          lbl.append(cb, document.createTextNode(isBlank(v) ? L.empty : v));
          list.appendChild(lbl);
        });
      }
      search.addEventListener('input', renderList);
      clear.onclick = function () { values.forEach(function (v) { allowed.add(v); }); commit(); renderList(); };
      renderList();

      placePopup(pop, btn);
      search.focus();
    }

    headers.forEach(function (th, col) {
      // skip the "select all" checkbox column of model lists
      if (th.querySelector('input[type=checkbox]') || th.classList.contains('action-checkbox-column')) return;

      var tools = document.createElement('span');
      tools.className = 'tf-tools';
      var arrow = document.createElement('span');
      arrow.className = 'tf-arrow';
      tools.appendChild(arrow);
      (th.querySelector('.text') || th).appendChild(tools);   // model lists wrap the title in div.text

      // Sorting is always on; the funnel is skipped for data-filter="none".
      var mode = th.getAttribute('data-filter') || 'list';
      if (mode !== 'none') {
        var btn = document.createElement('button');
        btn.type = 'button'; btn.className = 'tf-btn'; btn.innerHTML = FUNNEL;
        btn.setAttribute('aria-label', 'Filter');
        btn._mode = mode;
        tools.appendChild(btn);
        btn.addEventListener('click', function (e) {
          e.stopPropagation(); e.preventDefault();
          if (openPop && openPop._btn === btn) { closePop(); return; }
          buildPopup(col, btn);
          if (openPop) openPop._btn = btn;
        });
      }

      th.classList.add('tf-sortable-th');
      // The list is already sorted the way Django's ?o= says: show that as the start state.
      if (th.classList.contains('sorted')) {
        sort.col = col;
        sort.dir = th.classList.contains('descending') ? -1 : 1;
        th.classList.remove('sorted', 'ascending', 'descending');
      }
      th.addEventListener('click', function (e) {
        if (e.target.closest('.tf-btn')) return;
        if (e.target.closest('a')) e.preventDefault();   // stay on this page
        if (sort.col !== col) { sort.col = col; sort.dir = 1; }
        else if (sort.dir === 1) sort.dir = -1;
        else if (sort.dir === -1) { sort.dir = 0; sort.col = -1; }
        doSort();
      });
    });
    table.classList.add('tf-sortable');
    updateArrows();
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('table.report-table, table#result_list').forEach(init);
  });
})();