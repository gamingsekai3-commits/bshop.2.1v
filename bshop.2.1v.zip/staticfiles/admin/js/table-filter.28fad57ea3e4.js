/* Odoo-style column headers for admin tables.
 *
 *  - SERVER-SIDE sorting: model lists (Django's ?o=) and paginated reports (?sort=) are
 *    sorted by the server over ALL rows, on every page; the header link is followed as is.
 *    Only unpaginated tables (e.g. the overview) are sorted here in the browser.
 *  - Every sortable header always shows an indicator: dim \u21C5 when unsorted, \u25B2 / \u25BC when sorted.
 *  - Click a header  -> sort A-Z, click again Z-A, third click clears the sort.
 *    Model lists and paginated reports sort on the server (see above); small
 *    unpaginated tables sort in the browser on the same page.
 *  - Funnel icon     -> Excel/Odoo-like popup with a search box and a list of
 *    the values in that column; untick values to hide those rows.
 *  - Report tables can also turn sorting off per column with <th data-sort="no">
 *    (the funnel, if any, keeps working).
 *  - Report tables can choose per column with <th data-filter="...">:
 *      none  -> sorting only, no funnel icon
 *      list  -> the value list above (default, also used by model lists)
 *      count -> four fixed buckets: 0-9, 10-19, 20-29, 30+   (stock, units sold)
 *      money -> intervals built from the column's lowest / highest value
 *               (e.g. 100,000-500,000, 500,000-1,000,000 ...)             (price)
 *  - On Reports the funnel is SERVER-SIDE too: ticking boxes and pressing Apply reloads the
 *    page with ?f<column>=... so the filter covers every page, not just the one on screen.
 *    The options come from the server in the header's data-fopts attribute.
 *  - A "Reset all" button appears above the table whenever a sort or filter is active.
 *  - Reports never reload the page for sorting, filtering, paging or reset: the new HTML is fetched
 *    in the background and only #report-dyn (table + pager + reset button) is swapped. The URL and
 *    the Back button still work. No full-screen loader is shown.
 *
 * Works on `table.report-table` (Reports) and `#result_list` (model lists).
 * Sorting and filtering happen in the browser, so on a paginated model list
 * they only cover the rows on the current page.
 * Language comes from window.BSHOP_LANG (set in admin/base_site.html).
 */
(function () {
  'use strict';

  var EN = (window.BSHOP_LANG || document.documentElement.lang || 'mn').indexOf('en') === 0;
  var L = EN
    ? { search: 'Search…', all: 'All', clear: 'Clear filter', empty: '(empty)', none: 'No matches', apply: 'Apply', reset: 'Reset all filters & sorting' }
    : { search: 'Хайх…', all: 'Бүгд', clear: 'Цэвэрлэх', empty: '(хоосон)', none: 'Олдсонгүй', apply: 'Хэрэглэх', reset: 'Шүүлт, эрэмбийг бүгдийг цуцлах' };

  // Fixed buckets for the "count" / "money" modes on MODEL LISTS (browser-side). Reports get theirs from the server. `max` is the
  // inclusive upper edge of each bucket (the last one has none).
  var BUCKETS = {
    count: {
      labels: ['0 – 9', '10 – 19', '20 – 29', EN ? '30 and up' : '30-с дээш'],
      max: [9, 19, 29]
    },
    money: {
      labels: ['0 – 500,000', '500,001 – 1,000,000', '1,000,001 – 2,000,000', '2,000,001 – 3,000,000',
               EN ? '3,000,001 and up' : '3,000,001-с дээш'],
      max: [500000, 1000000, 2000000, 3000000]
    }
  };
  // Index of the bucket a cell falls in; blank / non-numeric cells fall in none.
  function bucketOf(text, mode) {
    if (isBlank(text)) return -1;
    var n = parseFloat(text.replace(/[,\s]/g, ''));
    if (isNaN(n)) return -1;
    var max = BUCKETS[mode].max;
    for (var i = 0; i < max.length; i++) if (n <= max[i]) return i;
    return max.length;
  }

  var FUNNEL = '<svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">' +
    '<path d="M1.5 1.5A.5.5 0 0 1 2 1h12a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.128.334L10 8.692V13.5a.5.5 0 0 1-.342.474l-3 1A.5.5 0 0 1 6 14.5V8.692L1.628 3.834A.5.5 0 0 1 1.5 3.5v-2z"/></svg>';

  var css = document.createElement('style');
  css.textContent =
    /* header tools: sort arrow + funnel always sit on ONE line, as a small tidy group */
    'table.tf-sortable thead th{white-space:nowrap}' +
    'table.tf-sortable thead th .text{display:flex;align-items:center;gap:6px;flex-wrap:nowrap}' +
    'table.tf-sortable thead th .clear{display:none}' +
    'table.tf-sortable thead th.num{text-align:right}' +
    'table.tf-sortable thead th.num .text{justify-content:flex-end}' +
    '.tf-tools{display:inline-flex;flex-wrap:nowrap;align-items:center;gap:2px;margin-left:6px;vertical-align:middle;white-space:nowrap}' +
    '.tf-arrow{display:inline-flex;align-items:center;justify-content:center;width:18px;height:22px;font-size:10px;color:var(--primary,#417690)}' +
    '.tf-arrow.idle{opacity:.4;color:inherit}' +
    'th.tf-sortable-th:hover .tf-arrow.idle{opacity:.9}' +
    '.tf-btn{position:relative;display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border:0;background:transparent;' +
    'color:inherit;opacity:.45;cursor:pointer;padding:0;border-radius:6px;line-height:0;transition:background .15s,opacity .15s}' +
    '.tf-btn:hover{opacity:1;background:rgba(128,128,128,.18)}' +
    '.tf-btn.active{opacity:1;color:#fff;background:var(--primary,#417690)}' +
    '.tf-btn.active:hover{filter:brightness(1.1)}' +
    'table.tf-sortable thead th.tf-sortable-th{cursor:pointer;user-select:none}' +
    'table.tf-sortable .sortoptions{display:none}' +
    'table.tf-sortable thead th.tf-sortable-th a{cursor:pointer}' +
    '.report-table th .rs-mark{display:inline-block;min-width:12px;text-align:center}' +
    '.tf-pop{position:absolute;z-index:99998;width:240px;padding:10px;background:var(--body-bg,#fff);color:var(--body-fg,#333);' +
    'border:1px solid var(--hairline-color,#ddd);border-radius:10px;box-shadow:0 10px 28px rgba(0,0,0,.22);font-size:13px;' +
    'text-transform:none;letter-spacing:0;font-weight:400;text-align:left;opacity:0;transform:translateY(-6px);transition:opacity .25s ease,transform .25s ease}' +
    '.tf-pop.show{opacity:1;transform:none}' +
    '.tf-pop input[type=search]{width:100%;box-sizing:border-box;padding:6px 8px;margin-bottom:6px}' +
    '.tf-list{max-height:240px;overflow:auto;border-top:1px solid var(--hairline-color,#ddd);padding-top:4px}' +
    '.tf-list label{display:flex;align-items:center;gap:8px;padding:5px 4px;border-radius:6px;cursor:pointer;word-break:break-word}' +
    '.tf-list label:hover{background:var(--darkened-bg,#f5f5f5)}' +
    '.tf-list input{margin:0;flex:none}' +
    '.tf-foot{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:8px;padding-top:8px;border-top:1px solid var(--hairline-color,#ddd)}' +
    '.tf-foot button{border:0;background:transparent;color:var(--link-fg,#447e9b);cursor:pointer;font-size:12px;padding:4px 6px;border-radius:6px}' +
    '.tf-foot button:hover{background:var(--darkened-bg,#f5f5f5)}' +
    '.tf-foot button.tf-apply{background:var(--primary,#417690);color:#fff;font-weight:600;padding:5px 14px}' +
    '.tf-foot button.tf-apply:hover{filter:brightness(1.1)}' +
    '.tf-none{padding:6px 2px;color:var(--body-quiet-color,#888)}' +
    '#report-dyn{transition:opacity .15s}#report-dyn.tf-busy{opacity:.6;pointer-events:none}' +
    '.tf-toolbar{display:flex;justify-content:flex-end;margin:0 0 10px}' +
    '.tf-reset{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600;' +
    'text-decoration:none;cursor:pointer;color:var(--primary,#417690);background:transparent;border:1px solid var(--primary,#417690);transition:background .15s,color .15s}' +
    '.tf-reset:hover{background:var(--primary,#417690);color:#fff}';
  document.head.appendChild(css);

  var openPop = null;
  function closePop() {
    if (!openPop) return;
    var gone = openPop;
    openPop = null;
    gone.classList.remove('show');                       // fade out 0.5 s, then remove
    setTimeout(function () { gone.remove(); }, 500);
  }
  document.addEventListener('click', function (e) {
    if (openPop && !openPop.contains(e.target) && !e.target.closest('.tf-btn')) closePop();
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePop(); });

  function cellText(row, i) {
    var c = row.cells[i];
    return c ? c.textContent.replace(/\s+/g, ' ').trim() : '';
  }
  function isBlank(v) { return v === '' || v === '—' || v === '-'; }

  function init(table) {
    var thead = table.tHead, tbody = table.tBodies[0];
    if (!thead || !tbody) return;
    var serverSort = table.hasAttribute('data-server-sort') || table.id === 'result_list';
    var isModelList = table.id === 'result_list';
    var headers = Array.prototype.slice.call(thead.rows[0].cells);
    var rows = Array.prototype.slice.call(tbody.rows).filter(function (r) {
      return !r.querySelector('td[colspan]');
    });
    if (!rows.length && !serverSort) return;      // reports keep their funnels even when a filter leaves 0 rows
    rows.forEach(function (r, i) { r._tfIndex = i; });

    var filters = {};                                  // col -> Set of allowed values, or {range: Set of bucket indexes}
    var sort = { col: -1, dir: 0 };

    function apply() {
      rows.forEach(function (r) {
        var show = true;
        for (var c in filters) {
          var f = filters[c];
          var ok = f.range ? f.range.has(bucketOf(cellText(r, +c), f.mode)) : f.has(cellText(r, +c));
          if (!ok) { show = false; break; }
        }
        r.style.display = show ? '' : 'none';
      });
      updateReset();
    }

    // Model lists: one button that drops the browser-side column filters AND the
    // server-side sort / Django filters in the URL (the search box and page size stay).
    var resetBar = null;
    function urlHasState() {
      var p = new URLSearchParams(window.location.search), has = false;
      p.forEach(function (_v, k) { if (k !== 'q' && k !== 'per_page' && k !== 'p' && k !== '_popup' && k !== '_to_field') has = true; });
      return has;
    }
    function updateReset() {
      if (!isModelList) return;
      var on = Object.keys(filters).length > 0 || urlHasState();
      if (on && !resetBar) {
        resetBar = document.createElement('div');
        resetBar.className = 'tf-toolbar';
        var a = document.createElement('a');
        a.className = 'tf-reset'; a.href = '#'; a.textContent = '\u2715 ' + L.reset;
        a.addEventListener('click', function (e) {
          e.preventDefault();
          var keep = new URLSearchParams(window.location.search), out = new URLSearchParams();
          ['q', 'per_page', '_popup', '_to_field'].forEach(function (k) { if (keep.has(k)) out.set(k, keep.get(k)); });
          var qs = out.toString();
          window.location.href = window.location.pathname + (qs ? '?' + qs : '');
        });
        resetBar.appendChild(a);
        var anchor = table.closest('.results') || table;
        anchor.parentNode.insertBefore(resetBar, anchor);
      }
      if (resetBar) resetBar.style.display = on ? '' : 'none';
    }

    function doSort() {
      var col = sort.col, dir = sort.dir;
      var list = rows.slice();
      if (dir === 0 || col < 0) {
        list.sort(function (a, b) { return a._tfIndex - b._tfIndex; });
      } else {
        var vals = list.map(function (r) { return cellText(r, col); });
        var numeric = vals.every(function (v) { return isBlank(v) || /^-?[\d.,\s]+$/.test(v); });
        var key = function (r) {
          var v = cellText(r, col);
          if (isBlank(v)) return null;
          return numeric ? parseFloat(v.replace(/[,\s]/g, '')) : v;
        };
        list.sort(function (a, b) {
          var x = key(a), y = key(b);
          if (x === null && y === null) return 0;
          if (x === null) return 1;                    // empty cells always last
          if (y === null) return -1;
          var r = numeric ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true, sensitivity: 'base' });
          return dir * r;
        });
      }
      list.forEach(function (r) { tbody.appendChild(r); });
      updateArrows();
    }

    function updateArrows() {
      headers.forEach(function (h, i) {
        var a = h.querySelector('.tf-arrow');
        // Every sortable column always shows an indicator: a dim ⇅ until it is sorted, then ▲ / ▼.
        if (a) {
          var on = (i === sort.col && sort.dir);
          a.textContent = on ? (sort.dir === 1 ? '▲' : '▼') : '⇅';
          a.classList.toggle('idle', !on);
        }
        if (i === sort.col) return;
        h.classList.remove('sorted', 'ascending', 'descending');
      });
    }

    function placePopup(pop, btn) {
      document.body.appendChild(pop);
      var r = btn.getBoundingClientRect();
      var left = r.left + window.scrollX;
      left = Math.min(left, window.scrollX + document.documentElement.clientWidth - 240);
      pop.style.left = Math.max(4, left) + 'px';
      pop.style.top = (r.bottom + window.scrollY + 4) + 'px';
      openPop = pop;
      requestAnimationFrame(function () { requestAnimationFrame(function () { pop.classList.add('show'); }); });
    }

    // Filter-modes "count" / "money": a tick-list of the fixed buckets.
    function buildRangePopup(col, btn) {
      closePop();
      var mode = btn._mode, B = BUCKETS[mode].labels;
      function everyBucket() { return new Set(B.map(function (_, i) { return i; })); }
      var allowed = filters[col] ? new Set(filters[col].range) : everyBucket();
      var pop = document.createElement('div');
      pop.className = 'tf-pop';
      var list = document.createElement('div');
      list.className = 'tf-list';
      list.style.borderTop = '0';
      var foot = document.createElement('div');
      foot.className = 'tf-foot';
      var clear = document.createElement('button');
      clear.type = 'button'; clear.textContent = L.clear;
      foot.appendChild(clear);
      pop.append(list, foot);

      function commit() {
        if (allowed.size === B.length) delete filters[col]; else filters[col] = { range: new Set(allowed), mode: mode };
        btn.classList.toggle('active', !!filters[col]);
        apply();
      }
      function renderList() {
        list.innerHTML = '';
        B.forEach(function (label, i) {
          var lbl = document.createElement('label');
          var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = allowed.has(i);
          cb.onchange = function () { if (cb.checked) allowed.add(i); else allowed.delete(i); commit(); };
          lbl.append(cb, document.createTextNode(label));
          list.appendChild(lbl);
        });
      }
      clear.onclick = function () { allowed = everyBucket(); commit(); renderList(); };
      renderList();
      placePopup(pop, btn);
    }


    // ---- Reports: server-side funnel. Options come from the server (data-fopts);
    // Apply reloads the page with ?f<col>=... so every page is filtered, not one.
    function buildServerPopup(btn) {
      closePop();
      var f = btn._f;
      var allowed = new Set(f.selected.length ? f.selected : f.values);
      var pop = document.createElement('div');
      pop.className = 'tf-pop';
      var search = null;
      if (f.kind === 'list' && f.options.length > 8) {
        search = document.createElement('input');
        search.type = 'search'; search.placeholder = L.search;
        pop.appendChild(search);
      }
      var list = document.createElement('div');
      list.className = 'tf-list';
      if (!search) list.style.borderTop = '0';
      var foot = document.createElement('div');
      foot.className = 'tf-foot';
      var clear = document.createElement('button');
      clear.type = 'button'; clear.textContent = L.clear;
      var apply = document.createElement('button');
      apply.type = 'button'; apply.className = 'tf-apply'; apply.textContent = L.apply;
      foot.append(clear, apply);
      pop.append(list, foot);

      function go(values) {
        var params = new URLSearchParams(window.location.search);
        params.delete(f.param); params.delete('p');
        values.forEach(function (v) { params.append(f.param, v); });
        var q = params.toString();
        closePop();
        swapReport(window.location.pathname + (q ? '?' + q : ''), true);
      }
      function renderList() {
        var q = search ? search.value.trim().toLowerCase() : '';
        list.innerHTML = '';
        var n = 0;
        f.options.forEach(function (label, i) {
          if (q && label.toLowerCase().indexOf(q) === -1) return;
          n++;
          var v = f.values[i];
          var lbl = document.createElement('label');
          var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = allowed.has(v);
          cb.onchange = function () { if (cb.checked) allowed.add(v); else allowed.delete(v); apply.disabled = !allowed.size; };
          lbl.append(cb, document.createTextNode(label));
          list.appendChild(lbl);
        });
        if (!n) { var e = document.createElement('div'); e.className = 'tf-none'; e.textContent = L.none; list.appendChild(e); }
      }
      if (search) search.addEventListener('input', renderList);
      clear.onclick = function () { go([]); };
      apply.onclick = function () { go(allowed.size === f.values.length ? [] : Array.from(allowed)); };
      renderList();
      placePopup(pop, btn);
      if (search) search.focus();
    }

    function buildPopup(col, btn) {
      if (btn._f) return buildServerPopup(btn);
      if (btn._mode === 'count' || btn._mode === 'money') return buildRangePopup(col, btn);
      closePop();
      var values = [];
      var seen = {};
      rows.forEach(function (r) {
        var v = cellText(r, col);
        if (!seen.hasOwnProperty(v)) { seen[v] = 1; values.push(v); }
      });
      var numeric = values.every(function (v) { return isBlank(v) || /^-?[\d.,\s]+$/.test(v); });
      values.sort(function (a, b) {
        if (numeric) return (parseFloat(a.replace(/[,\s]/g, '')) || 0) - (parseFloat(b.replace(/[,\s]/g, '')) || 0);
        return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
      });
      var allowed = filters[col] ? new Set(filters[col]) : new Set(values);

      var pop = document.createElement('div');
      pop.className = 'tf-pop';
      var search = document.createElement('input');
      search.type = 'search'; search.placeholder = L.search;
      var list = document.createElement('div');
      list.className = 'tf-list';
      var foot = document.createElement('div');
      foot.className = 'tf-foot';
      var clear = document.createElement('button');
      clear.type = 'button'; clear.textContent = L.clear;
      foot.appendChild(clear);
      pop.append(search, list, foot);

      function commit() {
        if (allowed.size === values.length) delete filters[col]; else filters[col] = new Set(allowed);
        btn.classList.toggle('active', !!filters[col]);
        apply();
      }

      function renderList() {
        var q = search.value.trim().toLowerCase();
        var shown = values.filter(function (v) { return (isBlank(v) ? L.empty : v).toLowerCase().indexOf(q) !== -1; });
        list.innerHTML = '';
        if (!shown.length) { var n = document.createElement('div'); n.className = 'tf-none'; n.textContent = L.none; list.appendChild(n); return; }

        var allLbl = document.createElement('label');
        var allCb = document.createElement('input'); allCb.type = 'checkbox';
        allCb.checked = shown.every(function (v) { return allowed.has(v); });
        allLbl.append(allCb, document.createTextNode(L.all));
        allCb.onchange = function () {
          shown.forEach(function (v) { if (allCb.checked) allowed.add(v); else allowed.delete(v); });
          commit(); renderList();
        };
        list.appendChild(allLbl);

        shown.forEach(function (v) {
          var lbl = document.createElement('label');
          var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = allowed.has(v);
          cb.onchange = function () {
            if (cb.checked) allowed.add(v); else allowed.delete(v);
            commit();
            allCb.checked = shown.every(function (x) { return allowed.has(x); });
          };
          lbl.append(cb, document.createTextNode(isBlank(v) ? L.empty : v));
          list.appendChild(lbl);
        });
      }
      search.addEventListener('input', renderList);
      clear.onclick = function () { values.forEach(function (v) { allowed.add(v); }); commit(); renderList(); };
      renderList();

      placePopup(pop, btn);
      search.focus();
    }

    headers.forEach(function (th, col) {
      // skip the "select all" checkbox column of model lists
      if (th.querySelector('input[type=checkbox]') || th.classList.contains('action-checkbox-column')) return;

      var tools = document.createElement('span');
      tools.className = 'tf-tools';
      // Sorting is on unless the column says data-sort="no"; the funnel is
      // skipped for data-filter="none". Either can be off independently.
      var sortable = th.getAttribute('data-sort') !== 'no';
      // Server-sorted report tables draw their own mark inside the header link;
      // model lists get theirs here, read from the classes Django put on the <th>.
      if (sortable && (!serverSort || isModelList)) {
        var arrow = document.createElement('span');
        arrow.className = 'tf-arrow';
        if (isModelList) {
          var isSorted = th.classList.contains('sorted');
          arrow.textContent = isSorted ? (th.classList.contains('descending') ? '▼' : '▲') : (th.classList.contains('sortable') ? '⇅' : '');
          arrow.classList.toggle('idle', !isSorted);
        }
        tools.appendChild(arrow);
      }
      (th.querySelector('.text') || th).appendChild(tools);   // model lists wrap the title in div.text
      var mode = th.getAttribute('data-filter') || 'list';
      var fopts = null;
      if (serverSort && !isModelList) {              // Reports: the funnel exists only if the server sent options
        try { fopts = JSON.parse(th.getAttribute('data-fopts') || 'null'); } catch (e) { fopts = null; }
        if (!fopts) mode = 'none';
      }
      if (mode !== 'none') {
        var btn = document.createElement('button');
        btn.type = 'button'; btn.className = 'tf-btn'; btn.innerHTML = FUNNEL;
        btn.setAttribute('aria-label', 'Filter');
        btn._mode = mode;
        if (fopts) { btn._f = fopts; btn.classList.toggle('active', th.getAttribute('data-factive') === '1'); }
        tools.appendChild(btn);
        btn.addEventListener('click', function (e) {
          e.stopPropagation(); e.preventDefault();
          if (openPop && openPop._btn === btn) { closePop(); return; }
          buildPopup(col, btn);
          if (openPop) openPop._btn = btn;
        });
      }

      if (serverSort) {
        // Clicking anywhere on the header follows its sort link (the server sorts all pages).
        if (th.querySelector('a[href]')) {
          th.classList.add('tf-sortable-th');
          th.addEventListener('click', function (e) {
            if (e.target.closest('a') || e.target.closest('.tf-btn')) return;
            th.querySelector('a[href]').click();
          });
        }
        return;
      }
      if (!sortable) return;
      th.classList.add('tf-sortable-th');
      // The list is already sorted the way Django's ?o= says: show that as the start state.
      if (th.classList.contains('sorted')) {
        sort.col = col;
        sort.dir = th.classList.contains('descending') ? -1 : 1;
        th.classList.remove('sorted', 'ascending', 'descending');
      }
      th.addEventListener('click', function (e) {
        if (e.target.closest('.tf-btn')) return;
        if (e.target.closest('a')) e.preventDefault();   // stay on this page
        if (sort.col !== col) { sort.col = col; sort.dir = 1; }
        else if (sort.dir === 1) sort.dir = -1;
        else if (sort.dir === -1) { sort.dir = 0; sort.col = -1; }
        doSort();
      });
    });
    table.classList.add('tf-sortable');
    if (!serverSort) updateArrows();
    updateReset();
  }

  // ---------------------------------------------------------------------
  // Reports: swap #report-dyn in place instead of navigating
  // ---------------------------------------------------------------------
  var swapSeq = 0;
  function swapReport(url, push) {
    var dyn = document.getElementById('report-dyn');
    if (!dyn || !window.fetch || !window.DOMParser) { window.location.href = url; return; }
    var seq = ++swapSeq, slow = setTimeout(function () { dyn.classList.add('tf-busy'); }, 400);
    closePop();
    fetch(url, { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function (res) {
        if (!res.ok || new URL(res.url).pathname !== new URL(url, window.location.href).pathname) throw new Error('nav');
        return res.text();
      })
      .then(function (text) {
        if (seq !== swapSeq) return;                         // a newer click already won
        var next = new DOMParser().parseFromString(text, 'text/html').getElementById('report-dyn');
        if (!next) throw new Error('nav');
        dyn.innerHTML = next.innerHTML;
        dyn.querySelectorAll('table.report-table').forEach(init);
        if (push) history.pushState({ tf: 1 }, '', url);
      })
      .catch(function () { if (seq === swapSeq) window.location.href = url; })   // anything odd: normal page load
      .then(function () { clearTimeout(slow); dyn.classList.remove('tf-busy'); });
  }

  // Capture phase, so we run before admin-page-loader.js: it ignores clicks that are
  // already defaultPrevented, which is why no loading overlay appears.
  document.addEventListener('click', function (e) {
    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var a = e.target.closest && e.target.closest('#report-dyn th a.rs-link, #report-dyn .bshop-pager a[href], #report-dyn a.tf-reset');
    if (!a || !a.getAttribute('href')) return;
    e.preventDefault();
    swapReport(a.getAttribute('href'), true);
  }, true);
  // Rows-per-page dropdown: its inline onchange would navigate; take over instead.
  document.addEventListener('change', function (e) {
    var sel = e.target;
    if (!sel.closest || !sel.closest('#report-dyn .bshop-pager select')) return;
    e.stopPropagation();
    swapReport(sel.value, true);
  }, true);
  window.addEventListener('popstate', function () {
    if (document.getElementById('report-dyn')) swapReport(window.location.pathname + window.location.search, false);
  });

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('table.report-table, table#result_list, table.ov-table').forEach(init);
    if (document.getElementById('report-dyn')) history.replaceState({ tf: 1 }, '', window.location.href);
  });
})();